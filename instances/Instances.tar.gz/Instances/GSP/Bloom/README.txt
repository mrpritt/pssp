Instances from An Ant Colony Optimization Algorithm for Shop Scheduling Problems 2004 Bloom Sampels
Replicated exacly. Contacted the author for original instances, trasformed into psi format.
whizzkids97.psi is traformed from the original instance which has a different format.

done in february 2015
